#!/bin/sh
set -eu
cat /proc/$$/stat >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/control/target-before.stat
cat /proc/$PPID/stat >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/control/tracer-before.stat
readlink /proc/$PPID/exe >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/control/tracer-exe.txt
exec setpriv --reuid=1001 --regid=1001 --clear-groups env -i PATH=/usr/bin:/bin /home/runner/work/Tunveo/Tunveo/bin/ret-control >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/control/native-stdout.log 2>/home/runner/work/Tunveo/Tunveo/artifacts/experiment/control/native-stderr.log
