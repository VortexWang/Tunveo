#!/bin/sh
exec setpriv --reuid=1001 --regid=1001 --clear-groups env -i PATH=/usr/bin:/bin /home/runner/work/Tunveo/Tunveo/bin/ret-control >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/control/native-stdout.log 2>/home/runner/work/Tunveo/Tunveo/artifacts/experiment/control/native-stderr.log
