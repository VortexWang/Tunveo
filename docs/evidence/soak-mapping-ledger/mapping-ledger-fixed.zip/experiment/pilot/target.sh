#!/bin/sh
set -eu
cat /proc/$$/stat >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/pilot/target-before.stat
cat /proc/$PPID/stat >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/pilot/tracer-before.stat
readlink /proc/$PPID/exe >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/pilot/tracer-exe.txt
exec setpriv --reuid=1001 --regid=1001 --clear-groups env -i PATH=/usr/bin:/bin /home/runner/work/Tunveo/Tunveo/bin/probe --transport 3 --mode 1 --duration 15s --warmup 12s --sample-interval 5s --workers 2 --qps 10 --pool-min 16 --pool-max 64 --artifacts /home/runner/work/Tunveo/Tunveo/artifacts/experiment/pilot/native >/home/runner/work/Tunveo/Tunveo/artifacts/experiment/pilot/native-stdout.log 2>/home/runner/work/Tunveo/Tunveo/artifacts/experiment/pilot/native-stderr.log
