import itertools,json,hashlib,re
from collections import Counter,defaultdict
from pathlib import Path
root=Path('artifacts/lifecycle-100/final-acceptance')
pairs=['tunveo/tunveo','tunveo/upstream','upstream/tunveo']
profiles=[(p,t,'explicit-ip') for p,t in itertools.product(pairs,range(3))]+[('tunveo/tunveo',2,i) for i in ['default-ip','explicit-dns']]
def key(pair,tls,identity,t,m,pool,i,n):return (pair,tls,identity,t,m,pool[0],pool[1],i,n)
expected=set()
for pair,tls,identity in profiles:
 for t,m,pool,i,n in itertools.product(range(4),[1,2],[(2,8),(64,1024)],range(1,11),[None]+(['untrusted-ca','wrong-hostname','expired'] if tls==2 else [])):
  expected.add(key(pair,tls,identity,t,m,pool,i,n))
assert len(expected)==4160
seen=set();groups=defaultdict(Counter);failures=[];hashes={};binary_hashes=defaultdict(set);cleanup=Counter()
for path in sorted(root.rglob('report.json')):
 raw=path.read_bytes();r=json.loads(raw);assert r['status'] in ('passed','failed'),path
 hashes[str(path.relative_to(root))]=hashlib.sha256(raw).hexdigest()
 for name,meta in r['binaries'].items():binary_hashes[name].add(meta['sha256'])
 info=r['binaries']['tunveo']['go_build_info'];assert 'go1.26.10' in info and 'vcs.modified=false' in info and 'vcs.revision=bde88b04854551e88bcbf8edd35f2debb79f05c2' in info
 for x in r['results']:
  k=key(x['pair_server_client'],x['tls'],x['identity'],x['transport'],x['mode'],(x['pool']['min'],x['pool']['max']),x['iteration'],x['negative']);assert k in expected and k not in seen,k;seen.add(k)
  groups[(x['pair_server_client'],x['identity'],'negative' if x['negative'] else 'positive')][x['status']]+=1
  for p in x['cleanup']:
   cleanup['reaped' if p['reaped'] else 'not_reaped']+=1;cleanup['forced' if p['forced_kill'] else 'graceful_or_already_exited']+=1
   if p['forced_kill']:assert x['status']=='failed'
  if x['status']=='passed' and x['negative'] is None:
   for phase,length,protocol in [('tcp_echo',32768,'tcp'),('udp_echo',512,'udp')]:
    e=x['phases'][phase];assert e['attempts']==1 and e['sent_bytes']==e['received_bytes']==length and e['protocol']==protocol
    assert e['local_endpoint']!=e['peer_endpoint'] and e['peer_endpoint']==['127.0.0.1',x['ports']['front']]
  if x['status']!='passed':
   record={k:x[k] for k in ('id','pair_server_client','tls','effective_tls','identity','negative','transport','mode','pool','iteration','failed_phase','error') if k in x};record['report']=str(path.relative_to(root));record['cleanup']=x['cleanup'];record['negotiated_tls_logs']={}
   for role,verb in [('server','Sending'),('client','Loading')]:
    log=(path.parent/x['id']/(role+'.log')).read_text();record['negotiated_tls_logs'][role]=re.findall(verb+r' tunnel config:.*?TLS=(\d)\|',log)
   failures.append(record)
assert all(len(v)==1 for v in binary_hashes.values()),binary_hashes
assert cleanup['not_reaped']==0,cleanup
result={'source_head':'e611f0e018dbb1733e1a8316f3e9b55097ebce5a','source_tree':'835a788ccbce4e057a34d125c9ce0b5709f0fa80','tested_checkout':'bde88b04854551e88bcbf8edd35f2debb79f05c2','scope':'Linux amd64; explicit-IP compatibility baseline plus maintained default-IP/explicit-DNS; bounded CA/name/expiry rejection; 10 process cases per cell','planned':{'positive':1760,'negative':2400,'total':4160},'observed':len(seen),'missing':len(expected-seen),'duplicates':0,'complete':seen==expected,'all_passed':seen==expected and not failures,'groups':[{'pair':p,'identity':i,'kind':k,'counts':dict(c)} for (p,i,k),c in sorted(groups.items())],'cleanup':dict(cleanup),'binary_sha256':{k:sorted(v) for k,v in binary_hashes.items()},'report_sha256':hashes,'failures':failures}
Path('artifacts/lifecycle-100/coverage-final.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['observed','missing','complete','all_passed','groups','cleanup']}))
